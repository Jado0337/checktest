<?php
require_once('vendor/autoload.php');
session_start();


$Servername = "localhost";
$username = "recyclepro_co_uk";
$password = "L3eEdkG4zYhce5DTfgewteW4";

try {
  $pdo = new PDO("mysql:host=$Servername;dbname=recyclepro_co_uk", $username, $password);
  // set the PDO error mode to exception
  $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  //echo "Connected successfully";
} catch(PDOException $e) {
  echo "Connection failed: " . $e->getMessage();
}


foreach($_SESSION['products'] AS $product){
//print_r($product);
$pid =  $product['pid'];
$price = $product['price'];

$stmt = $pdo->prepare("SELECT * FROM wr_product WHERE id=:id");
$stmt->execute(['id' => $pid]);

$data = $stmt->fetchAll();
// and somewhere later:
foreach ($data as $row) {
    
$fullname = $_POST['fullname'];
$product_name = $row['productname'];
$product_category_id = $row['category'];

$address_country = $_POST['country'];
$fullname2 =  $fullname;
$email2 = "sabirsaleem70@gmail.com";
$address_line_1_2 =  "a";
$address_line_2_2 = "b";
$address_line_3_2 =  "c";
$product_name2 = $product_name;

if($product_category_type=="Phones"){
    $parcel = "smallParcel";
}
else {
    $parcel = "parcel";
}

if($price<=100){
    $service_code = "BPL2";

}
else {
    $service_code = "SD1";
}


if($address_country==""){
$address_country2 = "United Kingdom";
}
else {
$address_country2 =  $address_country;
}



if($price==""){
$price2 = "-";
}
else {
$price2 = $price;
}

$shop_address1 = "Recyclepro";
$shop_address2 = "170 Slade Road, Erdington, Birmingham, West Midlands,";
$shop_address3 = "B23 7PX";

$userid = $_SESSION['userid'];
$stm1 = $pdo->prepare("SELECT * FROM wr_user WHERE id=:id");
$stm1->execute(['id' => $userid]);
$data1 = $stm1->fetchAll();
// and somewhere later:
foreach ($data1 as $row1) {
$numbers2 = $row1['phone'];
$email = $row1['email'];
$address1 = $row1['address1'];
$address2 = $row1['address2'];
$address3 = $row1['address2'];
$address_postcode2 = $row1['postcode'];
$Date_Time2 = $row1['timestamp'];
}

//echo "$order_id <br/>";
// Configure API key authorization: Bearer
$config = RoyalMail\ClickAndDrop\Rest\Api\Configuration::getDefaultConfiguration()->setApiKey('Authorization', 'e37ca209-f015-4a8c-948e-92cc194e43af');
// Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
// $config = RoyalMail\ClickAndDrop\Rest\Api\Configuration::getDefaultConfiguration()->setApiKeyPrefix('Authorization', 'Bearer');

$apiInstance = new RoyalMail\ClickAndDrop\Rest\Api\OrdersApi(
// If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
// This is optional, `GuzzleHttp\Client` will be used as default.
new GuzzleHttp\Client(),
$config
);
$data = array(
'items' => [[
"orderReference" => $product_name2,
'recipient' => [
'address' => [
"fullName" => $fullname2,
"companyName" => '-',
"addressLine1" => "170 Slade Road",
"addressLine2" => "-",
"addressLine3" => "-",
"city" => "Birmingham",
"county" => "West Midlands",
"postcode" => "B23 7PX",
"countryCode" => "UK"
],
"emailAddress" => "stagingsite1234@gmail.com"
],
'sender' => [
"tradingName" => "abc",
],
"billing" => [
"address" => [
"fullName" => $fullname2,
"companyName" => "sender address",
"addressLine1" => "170 Slade Road",
"addressLine2" => "-",
"addressLine3" => "-",
"city" => "Birmingham",
"county" => "West Midlands",
"postcode" => "B23 7PX",
"countryCode" => "UK"
],
"phoneNumber" => $numbers2,
"emailAddress" => "stagingsite1234@gmail.com"
],
"packages" => [[
"weightInGrams" => 2,
"packageFormatIdentifier" => $parcel
]],
"orderDate" => $Date_Time2,
"subtotal" => $price2,
"shippingCostCharged" => 0,
"total" => $price2,
"postageDetails" => [
"sendNotificationsTo" => "billing",
"serviceCode" => $service_code
],
"label" => [
"includeLabelInResponse" => true,
"includeCN" => true,
"includeReturnsLabel" => true
],


]]
);
$payload = json_encode($data);
$request = new \RoyalMail\ClickAndDrop\Rest\Api\Models\CreateOrdersRequest($data); // \RoyalMail\ClickAndDrop\Rest\Api\Models\CreateOrdersRequest |

try {
$result = $apiInstance->createOrdersAsync($request);
$json = json_decode($result, true);
$label = $json['createdOrders'][0]['label'];
$msg = "";
$lab = mb_substr($label, 0, 100);
$trackingNumber = $json['createdOrders'][0]['trackingNumber'];



$to = 'sabirsaleem70@gmail.com,aqeelnaeem@m6repairs.co.uk';

$subject = 'the subject';
$message = "<img src='https://chart.googleapis.com/chart?chs=300x300&cht=qr&chl=Label=2|QRCode=$lab  $trackingNumber    $product_name2|1DBarcode=$trackingNumber|SendersDetails=Recycle Pro
170 Slade Road
Birmingham
B23 7PX|RetDetails=Sabir Saleem\&ASHLYN \&ST. ALBANS\&AL3 8QE||&choe=UTF-8' />

";
$headers = 'From: info@recyclepro.co.uk'       . "\r\n" .
'Reply-To: info@recyclepro.co.uk' . "\r\n" .
'X-Mailer: PHP/' . phpversion();
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=UTF-8\r\n";

mail($to, $subject, $message, $headers);
    



} catch (Exception $e) {
echo 'Exception when calling OrdersApi->createOrdersAsync: ', $e->getMessage(), PHP_EOL;
}






}

}

?>
