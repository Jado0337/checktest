# AddressRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**fullName** | **string** |  | [optional] 
**companyName** | **string** |  | [optional] 
**addressLine1** | **string** |  | 
**addressLine2** | **string** |  | [optional] 
**addressLine3** | **string** |  | [optional] 
**city** | **string** |  | 
**county** | **string** |  | [optional] 
**postcode** | **string** |  | [optional] 
**countryCode** | **string** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


