# GetShippingDetailsResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**shippingCost** | **float** |  | 
**trackingNumber** | **string** |  | [optional] 
**shippingTrackingStatus** | **string** |  | [optional] 
**serviceCode** | **string** |  | [optional] 
**deliveryService** | **string** |  | [optional] 
**receiveEmailNotification** | **bool** |  | [optional] 
**receiveSmsNotification** | **bool** |  | [optional] 
**guaranteedSaturdayDelivery** | **bool** |  | [optional] 
**requestSignatureUponDelivery** | **bool** |  | [optional] 
**isLocalCollect** | **bool** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


