# GetVersionResource

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**commit** | **string** |  | [optional] 
**build** | **string** |  | [optional] 
**release** | **string** |  | [optional] 
**releaseDate** | [**\DateTime**](\DateTime.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


