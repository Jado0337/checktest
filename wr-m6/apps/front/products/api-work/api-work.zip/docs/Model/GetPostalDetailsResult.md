# GetPostalDetailsResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**title** | **string** |  | [optional] 
**firstName** | **string** |  | [optional] 
**lastName** | **string** |  | [optional] 
**companyName** | **string** |  | [optional] 
**addressLine1** | **string** |  | [optional] 
**addressLine2** | **string** |  | [optional] 
**addressLine3** | **string** |  | [optional] 
**city** | **string** |  | [optional] 
**county** | **string** |  | [optional] 
**postcode** | **string** |  | [optional] 
**countryCode** | **string** |  | [optional] 
**phoneNumber** | **string** |  | [optional] 
**emailAddress** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


