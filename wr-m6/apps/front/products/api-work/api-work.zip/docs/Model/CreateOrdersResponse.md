# CreateOrdersResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**successCount** | **int** |  | [optional] 
**errorsCount** | **int** |  | [optional] 
**createdOrders** | [**\RoyalMail\ClickAndDrop\Rest\Api\Models\CreateOrderResponse[]**](CreateOrderResponse.md) |  | [optional] 
**failedOrders** | [**\RoyalMail\ClickAndDrop\Rest\Api\Models\FailedOrderResponse[]**](FailedOrderResponse.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


