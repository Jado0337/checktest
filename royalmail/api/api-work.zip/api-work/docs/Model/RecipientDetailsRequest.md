# RecipientDetailsRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**address** | [**\RoyalMail\ClickAndDrop\Rest\Api\Models\AddressRequest**](AddressRequest.md) |  | [optional] 
**phoneNumber** | **string** |  | [optional] 
**emailAddress** | **string** |  | [optional] 
**addressBookReference** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


