# CreateOrderErrorResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**errorCode** | **int** |  | [optional] 
**errorMessage** | **string** |  | [optional] 
**fields** | [**\RoyalMail\ClickAndDrop\Rest\Api\Models\OrderFieldResponse[]**](OrderFieldResponse.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


