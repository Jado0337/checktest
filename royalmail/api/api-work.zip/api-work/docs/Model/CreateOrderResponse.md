# CreateOrderResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**orderIdentifier** | **int** |  | 
**orderReference** | **string** |  | [optional] 
**createdOn** | [**\DateTime**](\DateTime.md) |  | 
**orderDate** | [**\DateTime**](\DateTime.md) |  | [optional] 
**printedOn** | [**\DateTime**](\DateTime.md) |  | [optional] 
**manifestedOn** | [**\DateTime**](\DateTime.md) |  | [optional] 
**shippedOn** | [**\DateTime**](\DateTime.md) |  | [optional] 
**trackingNumber** | **string** |  | [optional] 
**label** | **string** | label in format base64 string | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


