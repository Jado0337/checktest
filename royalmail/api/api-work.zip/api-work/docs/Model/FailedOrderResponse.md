# FailedOrderResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**order** | [**\RoyalMail\ClickAndDrop\Rest\Api\Models\CreateOrderRequest**](CreateOrderRequest.md) |  | [optional] 
**errors** | [**\RoyalMail\ClickAndDrop\Rest\Api\Models\CreateOrderErrorResponse[]**](CreateOrderErrorResponse.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


