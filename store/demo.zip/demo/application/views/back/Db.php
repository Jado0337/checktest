<?php
//connect to mysql database
$con = mysqli_connect("localhost", "root", "", "recycleproshop") or die("Error " . mysqli_error($con));
?>