<section id="cart_items">
		<div class="container">
			<h3>Dear <?php echo $this->session->userdata("cus_name");?></h3>
<h4>Your Order Successfully complete....</h4><hr/>
			
<h6>Total payable amount(including vat) : $<?php echo $this->session->userdata("g_total");?></h6>

<h5 style="text-align: justify;">Thanks for purchase. Recfeive your order successfully. We will contact you ASAP with delivery details. For more details please check your registration mail.</h5>
			
		</div>
	</section> <!--/#cart_items-->
