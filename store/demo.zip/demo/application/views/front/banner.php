<style>
	div#b1:hover {
    transform: scale(1.05);
}
div#b1 {
    top: 0px;
    left: 0;
    
    background-repeat: no-repeat;
    background-position: center;
    background-size: cover;
    transition: transform .5s ease-out;
    position: inherit;
}

</style>
<div style="margin-bottom:4%;" class="container">
	<h2 style="font-size:40px;font-weight:800;color:#0d4561;text-align:center;margin-bottom:2%;">Welcome To Our Store</h2>
			<div style="border-top:1px solid #d4cccc;" class="row">
				<div id="b1" style="margin-top: 4%;text-align: -webkit-center;" class="col-sm-3">
					<div style="border:1px solid #d4cccc;padding:2%;background-color:#eeeeee;">
					<img src="<?php echo base_url()?>assets/front/images/home/shopping-basket.png" class="girl img-responsive slide" alt="" />
					<h3 style="color: #0d4561;font-size: 23px;font-weight: 600;margin-top: 2%;text-align: center;margin-bottom:2%;">Quality Products</h3>
				</div>
				</div>
				<div style="margin-top: 4%;text-align: -webkit-center;" class="col-sm-3">
					<div id="b1" style="border:1px solid #d4cccc;;padding: 2%;background-color:#eeeeee;">
					<img src="<?php echo base_url()?>assets/front/images/home/fast-delivery.png" class="girl img-responsive slide" alt="" />
					<h3 style="color: #0d4561;font-size: 23px;font-weight: 600;margin-top: 2%;text-align: center;margin-bottom:2%;">Fast Delivery</h3>
				</div>
				</div>
            
				<div style="margin-top: 4%;text-align: -webkit-center;" class="col-sm-3">
					<div id="b1" style="border:1px solid #d4cccc;;padding: 2%;background-color:#eeeeee;">
					<img src="<?php echo base_url()?>assets/front/images/home/credit-card.png" class="girl img-responsive slide" alt="" />
					<h3 style="color: #0d4561;font-size: 23px;font-weight: 600;margin-top: 2%;text-align: center;margin-bottom:2%;">Secure Payment</h3>
				</div>
				</div>
				<div style="margin-top: 4%;text-align: -webkit-center;" class="col-sm-3">
					<div id="b1" style="border:1px solid #d4cccc;;padding: 2%;background-color:#eeeeee;">
					<img src="<?php echo base_url()?>assets/front/images/home/technical-support.png" class="girl img-responsive slide" alt="" />
					<h3 style="color: #0d4561;font-size: 23px;font-weight: 600;margin-top: 2%;text-align: center;margin-bottom:2%;">Technical Support</h3>
				</div>
				</div>
            </div>
	    </div>
<div style="margin-bottom:4%;" class="container">

			<div class="row">
				<div id="b1" style="margin-top:4%;" class="col-sm-6">
					<img src="<?php echo base_url()?>assets/front/images/home/bannerone.jpg" class="girl img-responsive slide" alt="" />
				</div>
				<div id="b1" style="margin-top:4%;" class="col-sm-6">
					<img src="<?php echo base_url()?>assets/front/images/home/bannertwo.jpg" class="girl img-responsive slide" alt="" />
				</div>
            </div>
            <div  class="row">
				<div id="b1" style="margin-top:4%;" class="col-sm-6">
					<img src="<?php echo base_url()?>assets/front/images/home/bannerthree.jpg" class="girl img-responsive slide" alt="" />
				</div>
				<div id="b1" style="margin-top:4%;" class="col-sm-6">
					<img src="<?php echo base_url()?>assets/front/images/home/bannerfour.jpg" class="girl img-responsive slide" alt="" />
				</div>
            </div>
	    </div>