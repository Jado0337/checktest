<section id="advertisement">
		
			<img src="<?php echo base_url()?>assets/front/images/home/banner.jpg" alt="" />
		
	</section>